export const environment = {
  production: true,
  BASE_URL: '/'
  // BASE_URL: 'http://localhost:4200/api/',
};
