const GlobalConstants = {
    page: 1,
    limit: 5
}
